# Abdul Rahman • Munajaat Collection

A GitHub Pages-ready, dependency-free Munajaat website.

## Included
- Complete 10-Munajaat collection supplied for this project
- Responsive mobile + desktop layout
- Search and category filters
- Favourites saved with localStorage
- Automatic bookmark/resume
- Dark / light mode
- Adjustable reading text size
- Focus reading mode
- Copy and native share
- Built-in browser speech recitation (no API key)
- PWA manifest + service worker for offline use after first visit
- Install button for supported browsers
- Keyboard shortcuts: Ctrl/Cmd+K search, ←/→ previous/next

## GitHub Pages
1. Create a GitHub repository, for example `abdul-rahman-munajaat`.
2. Upload every file and the `icons` folder to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Save and open the generated Pages URL.

No build step or npm install is required.

## Notes
The Recite feature uses the browser's Web Speech API when available. Voice and pronunciation depend on the device/browser. The website stores favourites, bookmark, theme and font size locally in the user's browser.
