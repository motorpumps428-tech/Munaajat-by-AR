const MUNAJAT = [
{id:1,title:'Main Tere Saamne',category:'Tauba & Dua',text:`Main tere saamne jhuk rahaan hun khuda,
Mera koi nahin allah tere siwaah.

Mai gunaah gaar hun, mai siyaah kaar hun.
Mai Qata kaar hoon, mai sazaa vaar hun.

Mere sajdon mein teri hi hamd-o-sanaa,
Mera koi nahin allah tere sivaa.

Meri tauba hai tauba Ae mere ilaah,
Mujh gunaah gaar ko too na dena sazaa.

Meri aahon ko sunle Ae haajat rawaa,
Mera koi nahin Allah tere sivaah.

Mai to Ghaffaar hun, toone khud hi kaha,
Nahin Koi nahin hai, Bande kaa.

Baksh doon ga tumhe, ye hai waada tera,
Mera Koi nahin Allah tere siwaa.`},
{id:2,title:'Kis Se Maange',category:'Tawakkul',text:`Kis se maange Kahaan jaaen kise kahein,
Aur dunya mein haajat rawaa Kaun hai?

Sab Ka daata hai too, sab Ko deta hai too,
tere bandon Ka tere Siwaa Kaun hai?

Kaun maqbool hai, Kaun mardood hai,
be qabar Kya qabar tujhko Kya kaun hai?

jab tulenge amal sab ke meezaan par,
tab khulega ke Khota Khara kaun hai.

Kaun sunta hai faryaad mazloom kee,
Kis ke haathon mein kunji hai maqsoom ki.`},
{id:3,title:'Tu Ho Kisi Bhi Haal Mein',category:'Ishq & Justuju',text:`Tu ho kisi bhi haal mein maula se lau lagaye ja,
qudrat zul jalal mein kya nahin gid gidaye ja.

baithe gaa chain se agar kaam ke kya raheinge par,
gawna nikal sakein magar pinjre mein phad phadaye jaa.

Yoonhi bahai jaa dil ki lagee bujhaaye jaa,
Aahein bhi kheench kheench kar Aatish-e-gham badhai jaa.

husn tamaasha dost ko ishq karishma saaz too,
Khel yoonhi naye naye shaam-o-sahr dikhaaye jaa.

zar ben kisi ke naam ki dil pe yoonhi lagaaye jaa,
gau na mile jawaab kuch dar yunhi khat khataaye jaa.

Khulein voyaa na kholein dar is pe ho kyun teri nazar,
too to bas apna koankar yaani sadaa lagaaye jaa.

haan mujhe misl-e-kimiya khak mein too milaye jaa,
shaan meri ghataija rutba mera badhai jaa.

Sab ho hijab bartaraf dekhan tujhi ko har taraf,
Parde yuhin hatai jaa jalve yunhi dikhae jaa.

jaam pe jaam laai jaa, shaan-e-karam dikhai jaa,
pyaas meri badhai jaa, roz nai pilaye jaa.

poor nahin hai bekhudi, karta hun mastiyan sahi,
hosh mere udhai jaa aur abhi chakaai jaa.

teri balaa se kuch ho bas tooto adaa dikhae jaa,
rotaa hai roe kal jahan too yuhin muskurae jaa.

gham se kahan farag hai dil pe roz daag hai,
qabze mein tere baagh hai nat nae gul khilae jaa.`},
{id:4,title:'Yaad Rahe Bas Ya Rab (Part 1)',category:'Wird & Zikr',text:`Ab to rahe bas -taa dam-e- aaqir wirde- zubaan ae mere ilaah.

1. Yaad rahe bas ya rab tumara, rishun Mujhko faqat Tujhse ho mohabbat, khalaq se mai be-zaar rahun. Har dam zikr mein tere mast rahun sarshaar rahun. Hosh rahe na mujhko kisi ka, tera magar Hushiyaar rahoon.

2. Dono jahaan mein jo kuch bhi hai, sab hai tere zer-e-nageen. jin-o-ins-o-hoor-o-malaik, Arsh-o-Kursi, Charkh-e-zameen. Kaun-o-makaan mein Laaiq-e-sajda, tere siwa ae noore mubeen. Koi nahin hai, Koi nahin hai, Koi nahin hai, Koi nahin.

3. Tere gada ban kar main Kisi Ka dast-e-nigar ae shah na hoon. Banda-e-maal-o-zar na banun main, talib-e-izz-o-jaah na hoon. Raah pe teri padd ke qayamat tak mai kabhi be raah na hoon, chain na loon jab tak Raaz-e-wahdat Se aagaah na hoon.

4. Yaad mein teri sab ko bhula doon koi na mujhko yaad rahe, tujh par sab ghar baar luta doon, gaana-e-dil aabaad rahe. Sab khushiyoon Ko aag laga doon, gham se tere dil shaad rahe, sab ko nazar se apni giradoon, Tujhse fariyaad rahe.`},
{id:5,title:'Yaad Rahe Bas Ya Rab (Part 2)',category:'Wird & Zikr',text:`5. Nafs-o-shaitaan dono ne mil kar, haaye kiya hai mujhko tabaah. Ae mere maula meri madad kar, chahta hoon main -teri panaah. Lailaha illallahu, Lailaha illallah. mujh sa qalaq mein koi nahin jo bad kirdaar o naama siyaah, Tu bhi hai ghaffar hai ya rabb, baksh de mere saare gunaah.

6. Jab tak qalb rahe pahloo mein, jab tak tan mein jaan rahe lab pe tera naam rahe aur dil mein tera dhyaan rahe. jazb mein parraan hosh rahe aur aql meri hairan rahe, Tujhse ghaafil hargiz dil na mera ik aaon rahe.

Ab to rahe bas taa dame- aaqir vird-e-zabaan ae mere ilaah. La ilaha illallahu, La ilaha illallah.`},
{id:6,title:'Teri Rahmaton Se Hun Bekhabar',category:'Maghfirat',text:`Teri Rahmaton se hun bekhabar ye meri nazar ka qusur hai.

Teri Raah mein qaadam qaadam kahin arsh hai kahin toor hai.

Ye baja hai malik-e-dojahan meri bandagi mein kusur hain.

Ye qata hai meri qata magar tera naam bhi to Ghafoor hai.

Ye bataa mai tujh se milun kahan mujhe tujh se milna zaroor hai.

Kahin dil ki sharth na daalna ye dil gunahon se choor hai.

too baksh de mere gunaah too raheem hai tu ghafoor hai.`},
{id:7,title:'Dil-e-Maghmoom',category:'Tazkiya',text:`dil-e- Maghmoom Ko masroor Karde

dil-e- be noor Ko purnoor Karde

firozaan dil mein sham-e-toor karde

ye gosha noor se maamoor karde

Mera zaahir sanwar jaaye ilaahi

Mere Baatin ki zulmat door karde

Mai-o-wahdat pila makhmoor Karde

Muhabbat Ke nashe mein choor karde

na dil maail ho mera unki jaanib

jinhe teri ataa maghroor karde

hai meri ghaat mein Khud nafs mera

Khudaya is Ko be Maqdoor Karde`},
{id:8,title:'Dil Badal De',category:'Islaah-e-Qalb',text:`Hawa-o-hirs waala dil badal de

Mera Ghaflat mein dooba dil badal de

Badal de dil ki dunya dil badal de

Khudaaya fazl farma dil badal de

Gunahgaari mein Kab tak umr Kaatun

badal de mera rasta dil badal de

Sunoon mai naam tera dhadkanon mein

mazaa aajaye maula dil badal de

Karun qurbaan apni saari khushiyan

tu Apna gham ataa Kar dil badal de

Hataaloon aankh apni maa sivaa se

jiyoon mai teri qaatir dil badal de

Sahal farmaa musalsal yaad apni

qudaya rahm farma dil badal de

padaahun dar pe tere dil shikastaa

rahoon kyun dil shikasta dil badal de

tera ho jaaon itni aarzu hai

bas itni hai tamanna dil badal de

meri faryaad sunle mere maula

banale apna banda dil badal de`},
{id:9,title:'Garche Main Badkaar',category:'Aajizi',text:`Garche main badkaar-o-nalaaiq hun ae shah-e-jahaan,

par tere dar ko bata Ab chodh Kar jaaun kahaan.

Kaun hai tere siva mujh be nava ke vaaste.

Kashmakash se naa umeedi Kee havahon mein tabaah,

dekh mat mere amal Kar lutf par Apne nigah,

ya rab apne raham-o-Ahsaan-o-Ataa ke vaaste.

Charkh-e-isyaan sar pe hai zer-e-qadam bahr-e-alam,

chaar soo hai fauj-e-gham Kar jald ab bahr-e-karam,

Kuch rihai Ka sabab is mubtalaa ke vaaste.

hai ibaadat Ka sahaara aabidoon ke vaaste,

Aur takiyaa zahd Kaa hai zaahidon ke vaaste.

hai isaa-e-Aah! mujh be dast-o-paake vaaste.

naa-faqiree chahtaahun, naa ameeree ki talab,

naa ibaadat na wara na na quahish ilm-o-adab,

dard dil par chahiye mujhko Khuda ke vaaste.

aql-o-hosh-o-fikr aur nimaae dunya beshumaar,

Ki ataa toone mujhe par ab to ae parvardigaar,

baqsh vo nimat jo kaam Aae sadaa ke vaaste.`},
{id:10,title:'Aik Nashaa Saa Hai',category:'Zikr-e-Ilaahi',text:`Aik nashaa saa hai jo chaai hai tere naam ke saath

Aik tasalli si bhi Aae hai tere naam ke saath

Ambar-o-ood lutat hai teri yaad jameel

Aik qushbu si bhi Aae tere naam Ke saath

Goya Kaunain Ki daulat ko sameta is ne

dil ki dunya jo basaae hai tere naam ke saath

hai tera zikr halavat mein kuch aisa ke zabaan

ik naya zaiqa paaye hai tere naam ke saath

Dil tadapta hai sune jab bhi tera naam kahin

Aankh bhi ashk bahai hai tere naam ke saath

Qoob kiya ishq-e-ilaahi Kaa asar hota hai

Rooh bhi wajad mein aaye hai tere naam ke saath

hashr Kya hoga bhalaa in Ka teri deed ke din

jinka dil josh mein aae hai tere naam kesaath

Qoob jee bhar Ke jo karta hai tera zikr-e-faqeer

dil ki zulmath Komitae hai tere naam kesaath`}
];

const CATS=['All',...new Set(MUNAJAT.map(x=>x.category))];
const $=id=>document.getElementById(id);
const state={
  selected:Number(localStorage.getItem('munajaat-bookmark')||1),
  theme:localStorage.getItem('munajaat-theme')||'dark',
  font:Number(localStorage.getItem('munajaat-font')||20),
  search:'',category:'All',favorites:JSON.parse(localStorage.getItem('munajaat-favorites')||'[]'),
  focus:false,mobile:false,voice:false
};
function save(){localStorage.setItem('munajaat-bookmark',state.selected);localStorage.setItem('munajaat-theme',state.theme);localStorage.setItem('munajaat-font',state.font);localStorage.setItem('munajaat-favorites',JSON.stringify(state.favorites))}
function current(){return MUNAJAT.find(x=>x.id===state.selected)||MUNAJAT[0]}
function filtered(){const q=state.search.trim().toLowerCase();return MUNAJAT.filter(x=>(state.category==='All'||x.category===state.category)&&(!q||`${x.title} ${x.category} ${x.text}`.toLowerCase().includes(q)))}
function toast(msg){$('toast').textContent=msg;$('toast').hidden=false;clearTimeout(window.toastT);window.toastT=setTimeout(()=>{$('toast').hidden=true},1700)}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function render(){
  document.documentElement.classList.toggle('light',state.theme==='light');document.body.classList.toggle('focus',state.focus);
  const data=filtered();const cur=current();
  $('sidebar').classList.toggle('open',state.mobile);$('backdrop').hidden=!state.mobile;
  $('themeBtn').textContent=state.theme==='dark'?'☀️ Light':'🌙 Dark';$('focusBtn').textContent=state.focus?'↙ Exit focus':'⛶ Focus';
  $('query').value=state.search;$('queryMobile').value=state.search;$('catChips').innerHTML=CATS.map(c=>`<button class="chip ${state.category===c?'active':''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
  $('catChipsMobile').innerHTML=$('catChips').innerHTML;
  $('list').innerHTML=data.length?data.map(x=>`<button class="item ${x.id===state.selected?'active':''}" data-id="${x.id}"><div class="item-top"><span class="item-cat">${escapeHtml(x.category)}</span><span>${state.favorites.includes(x.id)?'❤️':'✦'}</span></div><div class="item-title">${escapeHtml(x.title)}</div><div class="item-preview">${escapeHtml(x.text.split('\n').find(Boolean)||'')}</div></button>`).join(''):`<div class="empty">No Munajaat found.<br>Try another search or category.</div>`;
  $('listMobile').innerHTML=$('list').innerHTML;
  $('heroStats').innerHTML=`<div class="stat"><small>Total Munajaat</small><strong>${MUNAJAT.length}</strong></div><div class="stat"><small>Favourites</small><strong>${state.favorites.length}</strong></div><div class="stat"><small>Showing</small><strong>${data.length}</strong></div><div class="stat"><small>Bookmark</small><strong>${cur.id}/${MUNAJAT.length}</strong></div>`;
  const fav=state.favorites.includes(cur.id);$('currentCat').textContent=cur.category;$('currentTitle').textContent=cur.title;$('currentMeta').textContent=`Munajaat ${cur.id} of ${MUNAJAT.length}`;$('readerText').innerHTML=cur.text.split('\n\n').map(p=>`<div class="verse">${escapeHtml(p)}</div>`).join('');document.documentElement.style.setProperty('--reader-font',state.font+'px');
  $('favBtn').textContent=fav?'♥ Remove Favourite':'♡ Add Favourite';$('voiceBtn').textContent=state.voice?'⏹ Stop Recitation':'🔊 Recite';
  $('prevBtn').disabled=cur.id<=1;$('nextBtn').disabled=cur.id>=MUNAJAT.length;$('progress').style.width=(cur.id/MUNAJAT.length*100)+'%';
  $('bookmarkName').textContent=cur.title;$('fontSize').textContent=state.font+'px';
  save();
}
function select(id){state.selected=Number(id);state.mobile=false;window.scrollTo({top:0,behavior:'smooth'});render();toast('Munajaat opened')}
async function copy(){try{await navigator.clipboard.writeText(`${current().title}\n\n${current().text}`);toast('Copied')}catch{toast('Copy is not available here')}}
async function share(){const c=current();if(navigator.share){try{await navigator.share({title:c.title,text:`${c.title}\n\n${c.text}`});toast('Shared')}catch{}}else copy()}
function toggleFav(){const id=current().id;state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];render();toast(state.favorites.includes(id)?'Added to favourites':'Removed from favourites')}
function recite(){if(state.voice){speechSynthesis.cancel();state.voice=false;render();return}if(!('speechSynthesis'in window)){toast('Recitation is not supported in this browser');return}state.voice=true;render();const u=new SpeechSynthesisUtterance(current().text);u.rate=.82;u.pitch=.95;u.lang='en-IN';u.onend=()=>{state.voice=false;render()};speechSynthesis.cancel();speechSynthesis.speak(u)}
function install(){if(window.__deferredInstall){window.__deferredInstall.prompt();window.__deferredInstall.userChoice.then(()=>window.__deferredInstall=null)}else toast('Use your browser menu → Add to Home Screen / Install App')}

function app(){document.body.innerHTML=`<div class="app"><aside class="sidebar" id="sidebar"><div class="brand"><div class="eyebrow">Munajaat Collection</div><h1>Abdul Rahman</h1><p>A calm digital library for Munajaat, duas and spiritual poetry.</p></div><div class="side-scroll"><div class="search"><input id="query" placeholder="Search title or verse…"><span>⌕</span></div><div class="chips" id="catChips"></div><div id="list"></div></div><div class="side-footer">© 2026 Abdul Rahman • GitHub Pages ready</div></aside><div class="drawer-backdrop" id="backdrop"></div><main class="main"><div class="topbar"><div class="topbar-inner"><div style="display:flex;align-items:center;gap:10px"><button class="icon-btn mobile-only" id="menuBtn">☰</button><div class="mobile-title"><div class="eyebrow">Abdul Rahman</div><strong>Munajaat Collection</strong></div></div><div class="top-actions"><button class="btn" id="installBtn">＋ Install</button><button class="btn" id="focusBtn">⛶ Focus</button><button class="btn" id="themeBtn">☀️ Light</button><button class="btn" id="settingsBtn">⚙ Settings</button></div></div></div><div class="content"><section class="hero"><div class="eyebrow">Spiritual Reading</div><h2>Munajaat for a quieter heart.</h2><p>Read, search, save, share and listen to the complete collection in a clean reading experience designed for mobile and desktop.</p><div class="hero-actions"><button class="btn primary" id="startBtn">Start Reading ↓</button><button class="btn" id="randomBtn">✦ Random Munajaat</button><button class="btn" id="favOnlyBtn">♡ Show Favourites</button></div><div class="stats" id="heroStats"></div></section><section class="reader" id="reader"><div class="reader-head"><div class="reader-head-row"><div><div class="eyebrow" id="currentCat"></div><div class="reader-title" id="currentTitle"></div><div class="meta" id="currentMeta"></div></div><div style="text-align:right"><div class="meta" id="bookmarkName"></div><div class="progress" style="width:180px;margin-top:9px"><i id="progress"></i></div></div></div><div class="toolbar"><button class="btn primary" id="favBtn"></button><button class="btn" id="copyBtn">⧉ Copy</button><button class="btn" id="shareBtn">↗ Share</button><button class="btn" id="voiceBtn">🔊 Recite</button><button class="btn" id="minusBtn">A−</button><button class="btn" id="plusBtn">A+</button></div></div><div class="reader-body" id="readerText"></div><div class="reader-bottom"><button class="btn" id="prevBtn">← Previous</button><span>Bookmark is saved automatically on this device.</span><button class="btn" id="nextBtn">Next →</button></div></section><section class="reflection"><div class="eyebrow">Daily Reflection</div><h3>La ilaha illallah</h3><p>Keep the heart connected with remembrance, humility and gratitude. Return here whenever you want a peaceful reading space.</p></section><div class="bottom-space"></div></div></main></div><div class="modal" id="settingsModal" hidden><div class="modal-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><div class="eyebrow">Settings</div><h3>Reading preferences</h3></div><button class="icon-btn" id="closeSettings">✕</button></div><div class="setting-row"><span>Font size</span><span><button class="btn" id="sminus">A−</button> <button class="btn" id="splus">A+</button> <span id="fontSize" style="margin-left:8px;color:var(--muted)"></span></span></div><div class="setting-row"><span>Theme</span><button class="btn" id="modalTheme"></button></div><div class="setting-row"><span>Clear saved data</span><button class="btn danger" id="clearData">Reset</button></div><div style="margin-top:18px;color:var(--muted);font-size:.84rem;line-height:1.7">The Recite button uses your browser's built-in speech engine, so no audio files or external API are required.</div></div></div><div class="modal" id="mobileModal" hidden><div class="modal-card"><h3>Menu</h3><div class="search"><input id="queryMobile" placeholder="Search…"><span>⌕</span></div><div class="chips" id="catChipsMobile"></div><div id="listMobile"></div><button class="btn" id="closeMobile" style="margin-top:10px;width:100%">Close</button></div></div><div class="toast" id="toast" hidden></div>`}

app();
['query','queryMobile'].forEach(id=>$(id).addEventListener('input',e=>{state.search=e.target.value;render()}));
document.addEventListener('click',e=>{
  const item=e.target.closest('[data-id]');if(item){select(item.dataset.id);return}
  const cat=e.target.closest('[data-cat]');if(cat){state.category=cat.dataset.cat;render();return}
});
$('menuBtn').onclick=()=>{state.mobile=true;render()};$('backdrop').onclick=()=>{state.mobile=false;render()};
$('startBtn').onclick=()=>{$('reader').scrollIntoView({behavior:'smooth',block:'start'})};
$('randomBtn').onclick=()=>select(MUNAJAT[Math.floor(Math.random()*MUNAJAT.length)].id);
$('favOnlyBtn').onclick=()=>{state.category='All';state.search='';const data=MUNAJAT.filter(x=>state.favorites.includes(x.id));if(data.length){state.selected=data[0].id;render();toast('Showing your favourites') }else toast('No favourites saved yet')};
$('favBtn').onclick=toggleFav;$('copyBtn').onclick=copy;$('shareBtn').onclick=share;$('voiceBtn').onclick=recite;
$('minusBtn').onclick=()=>{state.font=Math.max(16,state.font-1);render()};$('plusBtn').onclick=()=>{state.font=Math.min(30,state.font+1);render()};
$('prevBtn').onclick=()=>select(Math.max(1,current().id-1));$('nextBtn').onclick=()=>select(Math.min(MUNAJAT.length,current().id+1));
$('themeBtn').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';render()};$('focusBtn').onclick=()=>{state.focus=!state.focus;render()};
$('settingsBtn').onclick=()=>{render();$('settingsModal').hidden=false};$('closeSettings').onclick=()=>$('settingsModal').hidden=true;
$('modalTheme').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';render()};$('sminus').onclick=()=>{state.font=Math.max(16,state.font-1);render()};$('splus').onclick=()=>{state.font=Math.min(30,state.font+1);render()};
$('clearData').onclick=()=>{localStorage.removeItem('munajaat-favorites');localStorage.removeItem('munajaat-bookmark');localStorage.removeItem('munajaat-font');state.favorites=[];state.selected=1;state.font=20;render();toast('Saved data reset')};
$('installBtn').onclick=install;$('closeMobile').onclick=()=>{$('mobileModal').hidden=true};
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__deferredInstall=e});
window.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('query').focus()}if(e.key==='ArrowRight'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName))$('nextBtn').click();if(e.key==='ArrowLeft'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName))$('prevBtn').click()});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
render();
